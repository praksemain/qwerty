<?php include('./inc/header.php'); ?>
<section id="home" class="homebackground">
    <div class="home-overlay"></div>
        <div class="caption">
        </div>
</section>
<?php include('./inc/footer.php'); ?>

