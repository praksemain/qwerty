<?php include('./inc/header.php'); ?>

<section id="aboutus">
    <div class="container">
        <div class="row" id="section-title">
            <div class="col-md-12">
                <hr>
                <h2 class="text-center">Par mums</h2>
                <hr>
            </div>
        </div>
        <div class="container">
            <p>
                Uzņēmums SIA "Mainark" ir dibināts 2013.gada 9.aprīlī. Uzņēmuma galvenā darbības sfēra ir automašīnu rezerves daļu vairumtirdzniecība. Šobrīd uzņēmumā strādā 2 cilvēki. Nākotnē plānojam atvērt mazumtirdzniecības veikalu.
            </p>
        </div>
    </div>
</section>

<?php include('./inc/footer.php'); ?>

